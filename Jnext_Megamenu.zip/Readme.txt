Plugin Name: Jnext Megamenu
Company: Jnext Development
Developer: Jnext Magento Team
Compatible: Magento CE 2.0.11, Magento CE 2.1.3