var config = {
    map: {
        '*': {
            jnextmodernizr: 'Jnext_Megamenu/js/modernizr-2.8.3',
        }
    }
}