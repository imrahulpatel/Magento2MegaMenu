Plugin Name: Magento2 Megamenu
Company: Jnext Development
Developer: MuradAli
Compatible: Magento ce 2.0.9, 2.1.0
